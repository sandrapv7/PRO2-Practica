var searchData=
[
  ['ida_112',['ida',['../class_mensaje.html#a48e0fe3ebc3c180467fcacd9f56fed86',1,'Mensaje']]]
];
