var searchData=
[
  ['ida_34',['ida',['../class_mensaje.html#a48e0fe3ebc3c180467fcacd9f56fed86',1,'Mensaje']]],
  ['incrementar_5fcontador_5fmensajes_35',['incrementar_contador_mensajes',['../class_alfabeto.html#a735ac20e4c75d36fe824820ad25730f6',1,'Alfabeto']]]
];
