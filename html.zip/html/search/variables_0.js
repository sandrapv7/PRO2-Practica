var searchData=
[
  ['cjt_5falfabetos_107',['cjt_alfabetos',['../class_conjunto__alfabetos.html#af5550bc24d1b515873cd26853055e9a5',1,'Conjunto_alfabetos']]],
  ['cjt_5fmensajes_108',['cjt_mensajes',['../class_conjunto__mensajes.html#ae223865515d276756e2ba4e74631b897',1,'Conjunto_mensajes']]],
  ['contador_5fmensajes_109',['contador_mensajes',['../class_alfabeto.html#a41ec44bcbaa39b0f201be42d63cd0a6b',1,'Alfabeto']]]
];
