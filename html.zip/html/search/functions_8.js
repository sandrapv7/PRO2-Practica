var searchData=
[
  ['nuevo_5falfabeto_103',['nuevo_alfabeto',['../class_conjunto__alfabetos.html#a679a0f1fc2642edcb14d69b6429afcd0',1,'Conjunto_alfabetos']]],
  ['nuevo_5fmensaje_104',['nuevo_mensaje',['../class_conjunto__alfabetos.html#ac0338101eedb30017d8e3353d38c2531',1,'Conjunto_alfabetos::nuevo_mensaje()'],['../class_conjunto__mensajes.html#a5a40a80cde5ba7dbacca8b5b14a31b88',1,'Conjunto_mensajes::nuevo_mensaje()']]],
  ['numero_5falfabetos_105',['numero_alfabetos',['../class_conjunto__alfabetos.html#a50cd441737fbe5b1728864c4de2057fe',1,'Conjunto_alfabetos']]],
  ['numero_5fmensajes_106',['numero_mensajes',['../class_conjunto__mensajes.html#a8e7e2f87b8fbe0610ea4c09911bec32c',1,'Conjunto_mensajes']]]
];
