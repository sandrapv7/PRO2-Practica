var searchData=
[
  ['borra_5falfabeto_3',['borra_alfabeto',['../class_conjunto__alfabetos.html#a9c2c7f4f915cd59d10c3d056c7364ef3',1,'Conjunto_alfabetos']]],
  ['borra_5fmensaje_4',['borra_mensaje',['../class_conjunto__mensajes.html#a2952ec5f91f73770ea1c5a718ea224bf',1,'Conjunto_mensajes']]],
  ['borrar_5fmensaje_5',['borrar_mensaje',['../class_conjunto__alfabetos.html#a480e418403aed9150996dcb785b718ec',1,'Conjunto_alfabetos']]]
];
